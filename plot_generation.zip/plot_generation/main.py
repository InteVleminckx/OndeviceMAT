import pandas as pd
import matplotlib.pyplot as plt

df_tictactoe = pd.read_csv("seperate_results/TicTacToe.csv")
df_sudoku = pd.read_csv("seperate_results/Sudoku.csv")
df_tippytipper = pd.read_csv("seperate_results/TippyTipper.csv")
df_simpldo = pd.read_csv("seperate_results/SimpleDo.csv")
df_dictionary = pd.read_csv("seperate_results/Dictionary.csv")
df_expensetracker = pd.read_csv("seperate_results/ExpenseTracker.csv")
df_friendzone = pd.read_csv("seperate_results/Friendzone.csv")
df_news = pd.read_csv("seperate_results/News.csv")
df_notecalender = pd.read_csv("seperate_results/NoteCalender.csv")
df_alldata = pd.read_csv("simulation_results - AllData.csv")


def plot(df, title):

    emulator = df["Emulator"]
    client_server = df["Client-Server"]
    o_mat = df["On-Device"]

    data = [emulator, client_server, o_mat]

    fig, axe = plt.subplots()
    axe.set_title(title)
    axe.boxplot(data)
    plt.xticks([1, 2, 3], ["Emulator", "Client-Server", "O-MAT"])
    plt.ylabel("Time (s)")

    plt.savefig(f"result_folder/{title}.png")


def bar_plot(df, title):
    emulator = df["Emulator"].values[0]   # Extract the first element from the series
    client_server = df["Client-Server"].values[0]
    o_mat = df["O-MAT"].values[0]

    data = [emulator, client_server, o_mat]  # List of the actual data values

    fig, axe = plt.subplots()
    axe.set_title(title)
    axe.bar(["Emulator", "Client-Server", "O-MAT"], data)  # Adding colors to distinguish bars
    axe.set_ylabel("Time (s)")

    plt.savefig(f"result_folder/{title}.png")

plot(df_tictactoe, "Tic Tac Toe")
plot(df_sudoku, "Sudoku")
plot(df_tippytipper, "Tippy Tipper")
plot(df_simpldo, "Simple Do")
plot(df_dictionary, "Dictionary")
plot(df_expensetracker, "Expense Tracker")
plot(df_friendzone, "Friendzone")
plot(df_news, "News")
plot(df_notecalender, "Note Calender")
bar_plot(df_alldata, "Total Simulation Average")
